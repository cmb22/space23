'use client';

import React, { useEffect, useRef, useState } from 'react';
import FullCalendar from '@fullcalendar/react';
import timeGridPlugin from '@fullcalendar/timegrid';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import type { DateSelectArg, DatesSetArg, EventInput, EventClickArg } from '@fullcalendar/core';

// ✅ IMPORTANT: FullCalendar CSS nur hier importieren (nicht globals)
import './fullcalendar.css';

type Slot = {
    startUtc: string;
    endUtc: string;
    durationMinutes: number;
};

type OverrideRow = {
    id: number;
    teacherId: number;
    startUtc: string | Date;
    endUtc: string | Date;
    kind: 'add' | 'block';
};

function pad2(n: number) {
    return String(n).padStart(2, '0');
}

function minutesToHHMM(min: number) {
    const h = Math.floor(min / 60);
    const m = min % 60;
    return `${pad2(h)}:${pad2(m)}`;
}

function hhmmToMinutes(hhmm: string) {
    const [h, m] = hhmm.split(':').map(Number);
    return h * 60 + m;
}

function buildQuarterHourOptions() {
    const opts: { label: string; value: string }[] = [];
    for (let m = 0; m < 24 * 60; m += 15) {
        const label = minutesToHHMM(m);
        opts.push({ label, value: label });
    }
    return opts;
}

const timeOptions = buildQuarterHourOptions();
const weekdayOptions = [
    { label: 'Sunday', value: 0 },
    { label: 'Monday', value: 1 },
    { label: 'Tuesday', value: 2 },
    { label: 'Wednesday', value: 3 },
    { label: 'Thursday', value: 4 },
    { label: 'Friday', value: 5 },
    { label: 'Saturday', value: 6 },
];

export default function FullCalendarWeek() {
    const calendarRef = useRef<FullCalendar | null>(null);

    const [teacherId, setTeacherId] = useState<number | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    // manual draw mode
    const [mode, setMode] = useState<'add' | 'block'>('add');

    // repeat weekly controls (15-min increments)
    const [repeatWeekday, setRepeatWeekday] = useState<number>(2); // Tuesday
    const [repeatStart, setRepeatStart] = useState<string>('09:00');
    const [repeatEnd, setRepeatEnd] = useState<string>('12:00');
    const [repeatTimezone, setRepeatTimezone] = useState<string>('Europe/Berlin');

    const rangeRef = useRef<{ start: Date; end: Date } | null>(null);

    useEffect(() => {
        (async () => {
            const res = await fetch('/api/user', { cache: 'no-store' });
            const data = await res.json();
            setTeacherId(data?.id ?? null);
        })();
    }, []);

    async function fetchData(rangeStart: Date, rangeEnd: Date) {
        if (!teacherId) return { slots: [] as Slot[], overrides: [] as OverrideRow[] };

        const from = rangeStart.toISOString();
        const to = rangeEnd.toISOString();

        const [slotRes, ovRes] = await Promise.all([
            fetch(
                `/api/teachers/${teacherId}/free-slots?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`,
                { cache: 'no-store' }
            ),
            fetch(`/api/teachers/${teacherId}/availability-overrides`, { cache: 'no-store' }),
        ]);

        if (!slotRes.ok) throw new Error(await slotRes.text());
        if (!ovRes.ok) throw new Error(await ovRes.text());

        const slotData = await slotRes.json();
        const ovData = await ovRes.json();

        // We show only 30-min slots in calendar background
        const only30: Slot[] = (slotData?.slots ?? []).filter((s: Slot) => s.durationMinutes === 30);
        const overrides: OverrideRow[] = ovData ?? [];
        return { slots: only30, overrides };
    }

    function buildEvents(slots: Slot[], overrides: OverrideRow[]): EventInput[] {
        // free slots as background
        const free: EventInput[] = slots.map((s) => ({
            id: `free-${s.startUtc}`,
            start: s.startUtc,
            end: s.endUtc,
            display: 'background',
            backgroundColor: 'rgba(79, 156, 255, 0.25)',
        }));

        // overrides as clickable events (green/red)
        const ov: EventInput[] = overrides.map((o) => {
            const start = typeof o.startUtc === 'string' ? o.startUtc : o.startUtc.toISOString();
            const end = typeof o.endUtc === 'string' ? o.endUtc : o.endUtc.toISOString();
            const isAdd = o.kind === 'add';
            const bg = isAdd ? 'rgba(46, 204, 113, 0.28)' : 'rgba(255, 99, 99, 0.30)';

            return {
                id: `ov-${o.id}`,
                start,
                end,
                title: '',
                display: 'auto',
                backgroundColor: bg,
                borderColor: bg,
                textColor: 'transparent',
            };
        });

        return [...free, ...ov];
    }

    async function reloadCalendar() {
        if (!rangeRef.current || !teacherId) return;
        const api = calendarRef.current?.getApi();
        if (!api) return;

        setLoading(true);
        setError(null);
        try {
            const { slots, overrides } = await fetchData(rangeRef.current.start, rangeRef.current.end);
            const events = buildEvents(slots, overrides);

            api.removeAllEvents();
            api.addEventSource(events);
        } catch (e) {
            setError((e as Error).message);
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        if (!teacherId) return;
        if (!rangeRef.current) return;
        reloadCalendar();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [teacherId]);

    const handleDatesSet = (arg: DatesSetArg) => {
        rangeRef.current = { start: arg.start, end: arg.end };
        if (teacherId) reloadCalendar();
    };

    const handleSelect = async (arg: DateSelectArg) => {
        if (!teacherId) return;

        try {
            const res = await fetch(`/api/teachers/${teacherId}/availability-overrides`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    kind: mode,
                    startUtc: arg.start.toISOString(),
                    endUtc: arg.end.toISOString(),
                }),
            });

            if (!res.ok) throw new Error(await res.text());
            await reloadCalendar();
        } catch (e) {
            alert((e as Error).message);
        }
    };

    const handleEventClick = async (info: EventClickArg) => {
        if (!teacherId) return;

        const id = info.event.id;
        if (!id.startsWith('ov-')) return;

        const overrideId = Number(id.slice(3));
        if (!Number.isFinite(overrideId)) return;

        if (!confirm('Override löschen?')) return;

        const res = await fetch(
            `/api/teachers/${teacherId}/availability-overrides?id=${overrideId}`,
            { method: 'DELETE' }
        );

        if (!res.ok) {
            alert(await res.text());
            return;
        }

        await reloadCalendar();
    };

    async function applyRepeatRule() {
        if (!teacherId) return;

        const startMin = hhmmToMinutes(repeatStart);
        const endMin = hhmmToMinutes(repeatEnd);

        if (endMin <= startMin) {
            alert('Endzeit muss nach Startzeit liegen.');
            return;
        }
        if (startMin % 15 !== 0 || endMin % 15 !== 0) {
            alert('Bitte nur 15-Minuten-Takte verwenden.');
            return;
        }

        setLoading(true);
        setError(null);
        try {
            const res = await fetch(`/api/teachers/${teacherId}/availability-rules`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    weekday: repeatWeekday,
                    startMin,
                    endMin,
                    timezone: repeatTimezone,
                }),
            });

            if (!res.ok) throw new Error(await res.text());

            await reloadCalendar();
        } catch (e) {
            setError((e as Error).message);
            alert((e as Error).message);
        } finally {
            setLoading(false);
        }
    }

    return (
        <div style={{ padding: 16 }}>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 10, flexWrap: 'wrap' }}>
                <strong>Mode:</strong>
                <button onClick={() => setMode('add')} style={{ fontWeight: mode === 'add' ? 700 : 400 }}>
                    Add availability
                </button>
                <button onClick={() => setMode('block')} style={{ fontWeight: mode === 'block' ? 700 : 400 }}>
                    Block time
                </button>

                <span style={{ marginLeft: 12, fontWeight: 700 }}>Repeat weekly (next 3 months):</span>

                <label style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    Day
                    <select value={repeatWeekday} onChange={(e) => setRepeatWeekday(Number(e.target.value))}>
                        {weekdayOptions.map((w) => (
                            <option key={w.value} value={w.value}>
                                {w.label}
                            </option>
                        ))}
                    </select>
                </label>

                <label style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    Start
                    <select value={repeatStart} onChange={(e) => setRepeatStart(e.target.value)}>
                        {timeOptions.map((t) => (
                            <option key={t.value} value={t.value}>
                                {t.label}
                            </option>
                        ))}
                    </select>
                </label>

                <label style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    End
                    <select value={repeatEnd} onChange={(e) => setRepeatEnd(e.target.value)}>
                        {timeOptions.map((t) => (
                            <option key={t.value} value={t.value}>
                                {t.label}
                            </option>
                        ))}
                    </select>
                </label>

                <label style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    TZ
                    <input
                        value={repeatTimezone}
                        onChange={(e) => setRepeatTimezone(e.target.value)}
                        style={{ width: 140 }}
                        placeholder="Europe/Berlin"
                    />
                </label>

                <button onClick={applyRepeatRule} disabled={loading}>
                    Apply
                </button>

                {loading && <span style={{ opacity: 0.7 }}>Loading…</span>}
            </div>

            {error && <div style={{ color: 'crimson', whiteSpace: 'pre-wrap', marginBottom: 8 }}>{error}</div>}
            {!teacherId && <div>Not logged in.</div>}

            <FullCalendar
                ref={(r) => { calendarRef.current = r; }}
                plugins={[timeGridPlugin, dayGridPlugin, interactionPlugin]}
                initialView="timeGridWeek"
                allDaySlot={false}
                nowIndicator={true}
                height="auto"
                firstDay={1}
                selectable={true}
                selectMirror={true}
                select={handleSelect}
                eventClick={handleEventClick}
                slotDuration="00:15:00"
                slotLabelInterval="01:00:00"
                datesSet={handleDatesSet}
                events={[]}
                headerToolbar={{
                    left: 'today',
                    center: '',
                    right: 'prev title next',
                }}
            />
        </div>
    );
}