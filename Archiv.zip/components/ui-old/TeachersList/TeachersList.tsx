"use client";

import { useMemo } from "react";
import { useRouter } from "next/navigation";
import styles from "./TeachersList.module.css";

export type TeacherListItem = {
  id: number;
  name: string | null;
  email: string;
  bio: string | null;
  languages: string[];
  timezone: string;
  currency: string;
  avatarUrl: string | null;
  videoUrl: string | null;
  videoSource: string | null;
  fromPriceCents: number | null;
};

type Props = {
  teachers: TeacherListItem[];
  onBookLesson?: (teacherId: number) => void; // optional: opens your booking modal
};

const formatMoneyFromCents = (cents: number, currency: string) => {
  const value = cents / 100;
  try {
    return new Intl.NumberFormat("de-DE", {
      style: "currency",
      currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    }).format(value);
  } catch {
    // fallback if currency code is weird
    return `${value.toFixed(2)} ${currency}`;
  }
};

const getInitials = (nameOrEmail: string) => {
  const s = nameOrEmail.trim();
  if (!s) return "?";
  const parts = s.split(/\s+/).filter(Boolean);
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
  return (parts[0][0] ?? "?").toUpperCase();
};

export default function TeachersList({ teachers, onBookLesson }: Props) {
  const router = useRouter();

  const items = useMemo(() => teachers ?? [], [teachers]);

  if (!items.length) {
    return (
      <div className={styles.empty}>
        <h2>No teachers found</h2>
        <p>Try changing filters or add a teacher profile.</p>
      </div>
    );
  }

  return (
    <div className={styles.wrap}>
      {/* Optional: your filter row can go here later */}
      <div className={styles.grid}>
        {items.map((t) => {
          const displayName = t.name?.trim() || t.email;
          const initials = getInitials(displayName);
          const price =
            typeof t.fromPriceCents === "number"
              ? formatMoneyFromCents(t.fromPriceCents, t.currency || "EUR")
              : null;

          const onOpenTeacher = () => router.push(`/teachers/${t.id}`);

          return (
            <div key={t.id} className={styles.rowCard}>
              {/* LEFT: profile card */}
              <div
                className={styles.profileCard}
                role="link"
                tabIndex={0}
                onClick={onOpenTeacher}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") onOpenTeacher();
                }}
                aria-label={`Open teacher ${displayName}`}
              >
                <div className={styles.profileTop}>
                  <div className={styles.avatarWrap}>
                    {t.avatarUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        className={styles.avatar}
                        src={t.avatarUrl}
                        alt={`${displayName} avatar`}
                      />
                    ) : (
                      <div className={styles.avatarFallback} aria-hidden="true">
                        {initials}
                      </div>
                    )}
                  </div>

                  <div className={styles.profileMain}>
                    <div className={styles.nameRow}>
                      <div className={styles.nameBlock}>
                        <div className={styles.name}>{displayName}</div>
                        <div className={styles.sub}>Professional Teacher</div>
                      </div>

                      <button
                        type="button"
                        className={styles.heartBtn}
                        title="Save"
                        onClick={(e) => {
                          e.stopPropagation();
                          // later: add wishlist/favorites
                        }}
                      >
                        <span className={styles.heartIcon} aria-hidden="true">
                          ♡
                        </span>
                      </button>
                    </div>

                    <div className={styles.speaksRow}>
                      <span className={styles.speaksLabel}>Speaks:</span>
                      <div className={styles.pills}>
                        {(t.languages?.length ? t.languages : ["—"]).slice(0, 4).map((lang, idx) => (
                          <span key={`${t.id}-lang-${idx}`} className={styles.pill}>
                            {lang}
                          </span>
                        ))}
                        {t.languages && t.languages.length > 4 ? (
                          <span className={styles.pillMuted}>+{t.languages.length - 4}</span>
                        ) : null}
                      </div>
                    </div>

                    <div className={styles.bio}>
                      {t.bio ? t.bio : <span className={styles.bioMuted}>No bio yet.</span>}
                    </div>

                    <div className={styles.profileBottom}>
                      <div className={styles.stats}>
                        <div className={styles.rating}>
                          <span className={styles.star} aria-hidden="true">
                            ★
                          </span>
                          <span className={styles.ratingValue}>4.9</span>
                        </div>
                        <div className={styles.lessons}>369 Lessons</div>
                      </div>

                      <div className={styles.priceRow}>
                        <div className={styles.price}>
                          {price ? (
                            <>
                              <span className={styles.priceValue}>{price}</span>
                              <span className={styles.priceUnit}> / hour</span>
                            </>
                          ) : (
                            <span className={styles.priceMuted}>No price</span>
                          )}
                        </div>

                        <button
                          type="button"
                          className={styles.bookBtn}
                          onClick={(e) => {
                            e.stopPropagation();
                            if (onBookLesson) onBookLesson(t.id);
                            else router.push(`/teachers/${t.id}`); // fallback
                          }}
                        >
                          Book Lesson
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* RIGHT: media card */}
              <div
                className={styles.mediaCard}
                role="link"
                tabIndex={0}
                onClick={onOpenTeacher}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") onOpenTeacher();
                }}
                aria-label={`Open teacher ${displayName} media`}
              >
                <div className={styles.mediaInner}>
                  {t.videoUrl ? (
                    <div className={styles.videoPlaceholder}>
                      <div className={styles.playBadge} aria-hidden="true">
                        ▶
                      </div>
                      <div className={styles.mediaLabel}>Video</div>
                    </div>
                  ) : t.avatarUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      className={styles.mediaImg}
                      src={t.avatarUrl}
                      alt={`${displayName} preview`}
                    />
                  ) : (
                    <div className={styles.mediaFallback}>
                      <div className={styles.playBadge} aria-hidden="true">
                        ▶
                      </div>
                      <div className={styles.mediaLabel}>Preview</div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}