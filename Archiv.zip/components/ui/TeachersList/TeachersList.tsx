"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import styles from "./TeachersList.module.css";

type TeacherRow = {
  id: number;
  name: string | null;
  email: string;
  bio: string | null;
  languages: string[];
  timezone: string;
  currency: string;
  avatarUrl: string | null;
  videoUrl: string | null;
  videoSource: string | null;
  fromPriceCents: number | null;
};

function formatPrice(cents: number | null, currency: string) {
  if (cents == null) return "No price";
  const major = (cents / 100).toFixed(0);
  const symbol = currency === "EUR" ? "€" : currency === "CHF" ? "CHF" : currency;
  // PDF zeigt eher "EURO 35 / hour" – wir bleiben schlicht, aber gleiches Layout
  return `${symbol} ${major} / hour`;
}

function truncate(text: string, max = 140) {
  const t = text.trim();
  if (t.length <= max) return t;
  return t.slice(0, max).replace(/\s+\S*$/, "") + "…";
}

export default function TeachersList({ teachers }: { teachers: TeacherRow[] }) {
  const [openTeacherId, setOpenTeacherId] = useState<number | null>(null);

  const openTeacher = useMemo(
    () => teachers.find((t) => t.id === openTeacherId) ?? null,
    [openTeacherId, teachers]
  );

  return (
    <div className={styles.page}>
      {/* HERO (gelb + Deko wie im PDF, minimal aber optisch ähnlich) */}
      <header className={styles.hero}>
        <div className={styles.heroInner}>
          <div className={styles.brandRow}>
            <div className={styles.brand}>
              <span className={styles.brandDot} />
              <span className={styles.brandName}>Spaceship</span>
            </div>

            <nav className={styles.nav}>
              <Link className={styles.navLink} href="/sign-in">
                Log in
              </Link>
              <Link className={styles.navPrimary} href="/sign-up">
                Start now
              </Link>
            </nav>
          </div>

          <div className={styles.heroTitleRow}>
            <h1 className={styles.heroTitle}>Find your teacher</h1>
            <p className={styles.heroSubtitle}>
              Book a lesson in one click. (MVP layout like the PDF)
            </p>
          </div>
        </div>
      </header>

      {/* FILTER BAR (optisch wie PDF, erstmal ohne Logik) */}
      <section className={styles.filters}>
        <div className={styles.filtersInner}>
          <button className={styles.filterPill} type="button">
            <span className={styles.pillIcon}>🌐</span>
            Language <span className={styles.chev}>▾</span>
          </button>

          <button className={styles.filterPill} type="button">
            <span className={styles.pillIcon}>🏷️</span>
            Lesson Category <span className={styles.chev}>▾</span>
          </button>

          <button className={styles.filterPill} type="button">
            <span className={styles.pillIcon}>🕒</span>
            Lesson time <span className={styles.chev}>▾</span>
          </button>

          <button className={styles.filterPill} type="button">
            <span className={styles.pillIcon}>🧑‍🏫</span>
            Native speaker <span className={styles.chev}>▾</span>
          </button>

          <button className={styles.filterPill} type="button">
            <span className={styles.pillIcon}>€</span>
            Price <span className={styles.chev}>▾</span>
          </button>

          <div className={styles.filtersRight}>
            <button className={styles.filterPill} type="button">
              <span className={styles.pillIcon}>⛃</span>
              More <span className={styles.chev}>▾</span>
            </button>
          </div>
        </div>
      </section>

      {/* LIST */}
      <main className={styles.main}>
        <div className={styles.list}>
          {teachers.map((t) => {
            const displayName = t.name?.trim() || t.email;
            const bio = t.bio?.trim() || "No bio yet.";
            const price = formatPrice(t.fromPriceCents, t.currency);
            const langs = (t.languages || []).slice(0, 2);
            const extraLangCount = Math.max(0, (t.languages?.length || 0) - langs.length);

            return (
              <section key={t.id} className={styles.row}>
                {/* LEFT CARD */}
                <div className={styles.card}>
                  <Link className={styles.cardLinkArea} href={`/teachers/${t.id}`} aria-label={`Open teacher ${displayName}`} />

                  <div className={styles.cardInner}>
                    <div className={styles.avatarWrap}>
                      {t.avatarUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img className={styles.avatar} src={t.avatarUrl} alt={displayName} />
                      ) : (
                        <div className={styles.avatarFallback}>
                          {(displayName[0] || "T").toUpperCase()}
                        </div>
                      )}
                    </div>

                    <div className={styles.cardBody}>
                      <div className={styles.topRow}>
                        <div>
                          <div className={styles.name}>{displayName}</div>
                          <div className={styles.sub}>Professional Teacher</div>
                        </div>

                        <button
                          type="button"
                          className={styles.heart}
                          title="Save"
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            // TODO: wishlist
                          }}
                        >
                          ♡
                        </button>
                      </div>

                      <div className={styles.speaksRow}>
                        <div className={styles.speaksLabel}>Speaks:</div>

                        <div className={styles.langBadges}>
                          {langs.length ? (
                            langs.map((l) => (
                              <span key={l} className={styles.langBadge}>
                                {l}
                              </span>
                            ))
                          ) : (
                            <span className={styles.langBadgeMuted}>—</span>
                          )}

                          {extraLangCount > 0 && (
                            <span className={styles.langBadgeMuted}>+{extraLangCount}</span>
                          )}
                        </div>
                      </div>

                      <div className={styles.bio}>{truncate(bio, 150)}</div>

                      <div className={styles.metaRow}>
                        <div className={styles.rating}>
                          <span className={styles.star}>★</span>
                          <span className={styles.ratingValue}>4.9</span>
                          <span className={styles.dot}>·</span>
                          <span className={styles.lessons}>369 Lessons</span>
                        </div>
                      </div>

                      <div className={styles.bottomRow}>
                        <div className={styles.price}>{price}</div>

                        <button
                          type="button"
                          className={styles.bookBtn}
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            setOpenTeacherId(t.id);
                          }}
                        >
                          Book Lesson
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* RIGHT PREVIEW (wie PDF rechts: großes Media-Panel) */}
                <div className={styles.preview}>
                  {t.videoUrl ? (
                    <div className={styles.videoFrame}>
                      <div className={styles.playBtn} aria-hidden="true">
                        ▶
                      </div>
                      <div className={styles.previewLabel}>Preview</div>
                    </div>
                  ) : t.avatarUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img className={styles.previewImage} src={t.avatarUrl} alt="" />
                  ) : (
                    <div className={styles.videoFrame}>
                      <div className={styles.playBtn} aria-hidden="true">
                        ▶
                      </div>
                      <div className={styles.previewLabel}>Preview</div>
                    </div>
                  )}
                </div>
              </section>
            );
          })}
        </div>
      </main>

      {/* MODAL (MVP: Platzhalter für Kalender – Hookst du an deinen bestehenden Kalender an) */}
      {openTeacher && (
        <div
          className={styles.modalOverlay}
          role="dialog"
          aria-modal="true"
          onClick={() => setOpenTeacherId(null)}
        >
          <div
            className={styles.modal}
            onClick={(e) => e.stopPropagation()}
          >
            <div className={styles.modalHeader}>
              <div>
                <div className={styles.modalTitle}>Book Lesson</div>
                <div className={styles.modalSub}>
                  {openTeacher.name?.trim() || openTeacher.email}
                </div>
              </div>

              <button
                type="button"
                className={styles.modalClose}
                onClick={() => setOpenTeacherId(null)}
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            <div className={styles.modalBody}>
              <div className={styles.calendarPlaceholder}>
                Calendar goes here (teacherId: {openTeacher.id})
              </div>

              <div className={styles.modalHint}>
                Nächster Schritt: Slot anklicken → Booking anlegen → Stripe Checkout redirect.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}