export default function AiPracticePage() {
    return (
        <div style={{ padding: 24 }}>
            <h1>AI Practice</h1>
            <p>Coming soon 👀</p>
        </div>
    );
}