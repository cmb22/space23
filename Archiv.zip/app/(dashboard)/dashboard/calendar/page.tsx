import FullCalendarWeek from '@/components/ui/FullCalendarWeek/FullCalendarWeek';

export default function CalendarPage() {
    return <FullCalendarWeek />;
}