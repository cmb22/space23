import { NextResponse } from "next/server";
import { z } from "zod";
import { and, eq, lte, gte } from "drizzle-orm";
import { db } from "@/lib/db/drizzle";
import { availabilityOverrides } from "@/lib/db/schema";

const createSchema = z.object({
    kind: z.enum(["add", "block"]),
    startUtc: z.string().datetime(),
    endUtc: z.string().datetime(),
});

export async function GET(
    _req: Request,
    ctx: { params: Promise<{ teacherId: string }> }
) {
    const { teacherId: raw } = await ctx.params;
    const teacherId = Number(raw);
    if (!Number.isFinite(teacherId)) {
        return NextResponse.json({ error: "Invalid teacherId" }, { status: 400 });
    }

    const rows = await db
        .select()
        .from(availabilityOverrides)
        .where(eq(availabilityOverrides.teacherId, teacherId));

    return NextResponse.json(rows);
}

export async function POST(
    req: Request,
    ctx: { params: Promise<{ teacherId: string }> }
) {
    const { teacherId: raw } = await ctx.params;
    const teacherId = Number(raw);
    if (!Number.isFinite(teacherId)) {
        return NextResponse.json({ error: "Invalid teacherId" }, { status: 400 });
    }

    const body = createSchema.parse(await req.json());

    const start = new Date(body.startUtc);
    const end = new Date(body.endUtc);

    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime())) {
        return NextResponse.json({ error: "Invalid datetime" }, { status: 400 });
    }
    if (end <= start) {
        return NextResponse.json({ error: "Invalid range" }, { status: 400 });
    }

    // ✅ touching OR overlapping:
    // existing.startUtc <= end AND existing.endUtc >= start
    const whereTouchingOrOverlapping = and(
        eq(availabilityOverrides.teacherId, teacherId),
        eq(availabilityOverrides.kind, body.kind),
        lte(availabilityOverrides.startUtc, end),
        gte(availabilityOverrides.endUtc, start)
    );

    const touchingOrOverlapping = await db
        .select()
        .from(availabilityOverrides)
        .where(whereTouchingOrOverlapping);

    let mergedStart = start;
    let mergedEnd = end;

    for (const o of touchingOrOverlapping) {
        const oStart = o.startUtc instanceof Date ? o.startUtc : new Date(o.startUtc as any);
        const oEnd = o.endUtc instanceof Date ? o.endUtc : new Date(o.endUtc as any);

        if (oStart < mergedStart) mergedStart = oStart;
        if (oEnd > mergedEnd) mergedEnd = oEnd;
    }

    // Delete absorbed blocks
    if (touchingOrOverlapping.length > 0) {
        await db.delete(availabilityOverrides).where(whereTouchingOrOverlapping);
    }

    const [created] = await db
        .insert(availabilityOverrides)
        .values({
            teacherId,
            kind: body.kind,
            startUtc: mergedStart,
            endUtc: mergedEnd,
        })
        .returning();

    return NextResponse.json(created, { status: 201 });
}

export async function DELETE(
    req: Request,
    ctx: { params: Promise<{ teacherId: string }> }
) {
    const { teacherId: raw } = await ctx.params;
    const teacherId = Number(raw);
    if (!Number.isFinite(teacherId)) {
        return NextResponse.json({ error: "Invalid teacherId" }, { status: 400 });
    }

    const url = new URL(req.url);
    const id = Number(url.searchParams.get("id"));
    if (!Number.isFinite(id)) {
        return NextResponse.json({ error: "Missing/invalid id" }, { status: 400 });
    }

    const [deleted] = await db
        .delete(availabilityOverrides)
        .where(
            and(
                eq(availabilityOverrides.teacherId, teacherId),
                eq(availabilityOverrides.id, id)
            )
        )
        .returning();

    return NextResponse.json({ deleted: !!deleted });
}