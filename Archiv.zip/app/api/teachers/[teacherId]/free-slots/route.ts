import { NextResponse } from "next/server";
import { db } from "@/lib/db/drizzle";
import {
    availabilityRules,
    lessonOffers,
    availabilityOverrides,
    // bookings, // uncomment if you already added bookings and want filtering here
} from "@/lib/db/schema";
import { eq } from "drizzle-orm";
import { computeFreeSlots } from "@/lib/scheduling/computeFreeSlots";

type Slot = {
    startUtc: string;
    endUtc: string;
    durationMinutes: number;
};

const GRID_MINUTES = 30;

function isoToMs(iso: string) {
    return new Date(iso).getTime();
}

function overlaps(aStart: number, aEnd: number, bStart: number, bEnd: number) {
    return aStart < bEnd && aEnd > bStart;
}

// Create 30-min slots from an override range [start,end)
function overrideRangeTo30MinSlots(startUtcIso: string, endUtcIso: string): Slot[] {
    const out: Slot[] = [];
    const start = new Date(startUtcIso);
    const end = new Date(endUtcIso);

    if (!(start instanceof Date) || !(end instanceof Date)) return out;
    if (end.getTime() <= start.getTime()) return out;

    // We assume start/end already align to 30-min grid because FullCalendar selection uses slotDuration 00:30.
    // But still: we step by GRID_MINUTES and emit 30-min pieces.
    let t = start.getTime();
    const endMs = end.getTime();

    while (t + GRID_MINUTES * 60_000 <= endMs) {
        const s = new Date(t).toISOString();
        const e = new Date(t + GRID_MINUTES * 60_000).toISOString();
        out.push({ startUtc: s, endUtc: e, durationMinutes: GRID_MINUTES });
        t += GRID_MINUTES * 60_000;
    }

    return out;
}

export async function GET(
    req: Request,
    ctx: { params: Promise<{ teacherId: string }> }
) {
    const { teacherId: teacherIdRaw } = await ctx.params;
    const teacherId = Number(teacherIdRaw);

    if (!Number.isFinite(teacherId)) {
        return NextResponse.json({ error: "Invalid teacherId" }, { status: 400 });
    }

    const url = new URL(req.url);
    const fromIso = url.searchParams.get("from");
    const toIso = url.searchParams.get("to");

    if (!fromIso || !toIso) {
        return NextResponse.json({ error: "Missing from/to (ISO strings)" }, { status: 400 });
    }

    // 1) Load base rules + offers
    const [rules, offers] = await Promise.all([
        db.select().from(availabilityRules).where(eq(availabilityRules.teacherId, teacherId)),
        db.select().from(lessonOffers).where(eq(lessonOffers.teacherId, teacherId)),
    ]);

    // 2) Compute base free slots from rules
    const baseSlots: Slot[] = computeFreeSlots({
        rules: rules.map((r) => ({
            teacherId: r.teacherId,
            weekday: r.weekday,
            startMin: r.startMin,
            endMin: r.endMin,
            validFrom: r.validFrom ?? null,
            validTo: r.validTo ?? null,
            timezone: r.timezone,
        })),
        offers: offers.map((o) => ({
            teacherId: o.teacherId,
            durationMinutes: o.durationMinutes,
        })),
        fromIso,
        toIso,
    });

    // We only want to apply overrides at 30-min granularity:
    // - remove 30-min pieces that are blocked
    // - add 30-min pieces that are added
    // Then later you can expand to 60/90 by merging pieces (optional).
    const base30 = baseSlots.filter((s) => s.durationMinutes === 30);

    // 3) Load overrides
    const overrides = await db
        .select()
        .from(availabilityOverrides)
        .where(eq(availabilityOverrides.teacherId, teacherId));

    const blocks = overrides.filter((o) => o.kind === "block");
    const adds = overrides.filter((o) => o.kind === "add");

    const fromMs = isoToMs(fromIso);
    const toMs = isoToMs(toIso);

    // 4) Apply block overrides: remove any base slot that overlaps a block range
    let result30 = base30.filter((s) => {
        const sStart = isoToMs(s.startUtc);
        const sEnd = isoToMs(s.endUtc);

        // cut to requested range (safety)
        if (sEnd <= fromMs || sStart >= toMs) return false;

        return !blocks.some((b) => {
            const bStart = (b.startUtc instanceof Date ? b.startUtc : new Date(b.startUtc)).getTime();
            const bEnd = (b.endUtc instanceof Date ? b.endUtc : new Date(b.endUtc)).getTime();
            return overlaps(sStart, sEnd, bStart, bEnd);
        });
    });

    // 5) Apply add overrides: add 30-min slots from add ranges (dedupe)
    const addSlots30: Slot[] = [];
    for (const a of adds) {
        const aStartIso = (a.startUtc instanceof Date ? a.startUtc : new Date(a.startUtc)).toISOString();
        const aEndIso = (a.endUtc instanceof Date ? a.endUtc : new Date(a.endUtc)).toISOString();
        for (const s of overrideRangeTo30MinSlots(aStartIso, aEndIso)) {
            const sStart = isoToMs(s.startUtc);
            const sEnd = isoToMs(s.endUtc);
            if (sEnd <= fromMs || sStart >= toMs) continue;
            addSlots30.push(s);
        }
    }

    const key = (s: Slot) => `${s.startUtc}|${s.endUtc}|${s.durationMinutes}`;
    const existing = new Set(result30.map(key));
    for (const s of addSlots30) {
        const k = key(s);
        if (!existing.has(k)) {
            result30.push(s);
            existing.add(k);
        }
    }

    // 6) Sort
    result30.sort((a, b) => a.startUtc.localeCompare(b.startUtc));

    // 7) Optionally: rebuild 60-min slots from two consecutive 30-min slots (if you want)
    // For now: return only 30-min slots (fast, consistent with your minimum unit).
    // If you want 60 too, say "add 60" and I’ll extend it.
    const finalSlots = result30;

    return NextResponse.json({
        teacherId,
        fromIso,
        toIso,
        count: finalSlots.length,
        slots: finalSlots,
    });
}