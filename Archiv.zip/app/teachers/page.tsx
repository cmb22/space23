import TeachersList from "@/components/ui/TeachersList/TeachersList";

type TeacherRow = {
  id: number;
  name: string | null;
  email: string;
  bio: string | null;
  languages: string[];
  timezone: string;
  currency: string;
  avatarUrl: string | null;
  videoUrl: string | null;
  videoSource: string | null;
  fromPriceCents: number | null;
};

export default async function Page() {
  const res = await fetch("http://localhost:3000/api/teachers", {
    cache: "no-store",
  });

  if (!res.ok) {
    return (
      <div style={{ padding: 24 }}>
        <h1>Teachers</h1>
        <p>Failed to load teachers (HTTP {res.status}).</p>
      </div>
    );
  }

  const data = (await res.json()) as { teachers: TeacherRow[] };
  const teachers = data.teachers ?? [];

  return <TeachersList teachers={teachers} />;
}